# 輕鬆學會Android Kotlin實作開發：精心設計16個Lab讓你快速上手

我們會不定期更新程式碼，提供讀者更加舒適的範例

如內容有誤或有其他建言可透過『讀者回函』或是聯繫[『博碩文化 DrMaster』](https://www.facebook.com/DrMasterTW/)Facebook粉絲團

近期更動：

2019/03/06  使用AndroidX取代android.support元件庫。

2019/03/14  在範例程式加入註解說明。

2019/03/16  輕輕的優化Toast寫法。

2019/03/27  輕輕的優化Bundle判斷式與ViewHolder寫法。

2019/03/29  輕輕的優化範例專案（Lab2、7、8、9、10、13、14）。

2019/05/01  更新專案Kotlin與Gradle版本，優化Lab7與Lab14。

2019/05/11  更新Lab15 Firebase library版本。

2019/06/28  輕輕的優化範例專案並更新專案Kotlin與Gradle版本。

2019/07/02  讀者反映找不到附件圖片，請至附件資料夾直接取用，謝謝。

2019/07/15  更新專案Kotlin與Gradle版本。

2019/08/30  更新專案compileSdk、targetSdk、Gradle版本。
