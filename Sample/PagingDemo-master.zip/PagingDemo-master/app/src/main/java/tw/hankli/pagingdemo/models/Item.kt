package tw.hankli.pagingdemo.models

data class Item(val id: Int, val name: String)