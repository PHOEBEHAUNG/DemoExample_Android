package co.basavraj.Network

class WebUrls {

    companion object {
        const val BASE_URL: String = "https://www.dropbox.com/s/ypqp2vdirkhmj1f/"
        const val  GET_MOVIES="movies.json?dl=1"
    }
}